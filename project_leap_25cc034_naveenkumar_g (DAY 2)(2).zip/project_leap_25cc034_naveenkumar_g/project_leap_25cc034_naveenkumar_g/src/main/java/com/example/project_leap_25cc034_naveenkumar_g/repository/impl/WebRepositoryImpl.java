package com.example.project_leap_25cc034_naveenkumar_g.repository.impl;

import com.example.project_leap_25cc034_naveenkumar_g.repository.WebRepository;
import org.springframework.stereotype.Repository;

import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

@Repository
public class WebRepositoryImpl implements WebRepository {
    @Override
    public String writeData(String data) {
        try {
            FileWriter writer = new FileWriter("data.txt");

            writer.write(data);

            writer.close();

            return "Data written successfully!";
        }
        catch (IOException e) {
            return "An error occurred: " + e.getLocalizedMessage();
        }
    }
    @Override
    public String readData(){
        try{
            return Files.readString(Path.of("data.txt"));
        }catch(IOException e){
            return "Error Occured in the System : "+e.getLocalizedMessage();
        }
    }
    }

