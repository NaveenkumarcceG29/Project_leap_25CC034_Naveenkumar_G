package com.example.project_leap_25cc034_naveenkumar_g.services;

public interface WebServices{
    String writeData(String data);
    String readData();
}
