package com.example.project_leap_25cc034_naveenkumar_g.controller;

import com.example.project_leap_25cc034_naveenkumar_g.services.WebServices;
import com.example.project_leap_25cc034_naveenkumar_g.services.impl.WebServicesImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class WebController {
    @Autowired
    WebServices webService;
    @PostMapping("/data/write")
    String writeData(String data){
        return webService.writeData(data);
    }
    @GetMapping("data/read")
    String readData(){
        return webService.readData();
    }
}