package com.example.project_leap_25cc034_naveenkumar_g.services.impl;

import com.example.project_leap_25cc034_naveenkumar_g.repository.WebRepository;
import com.example.project_leap_25cc034_naveenkumar_g.repository.impl.WebRepositoryImpl;
import com.example.project_leap_25cc034_naveenkumar_g.services.WebServices;
import org.springframework.stereotype.Service;



@Service
public class WebServicesImpl implements WebServices{
    @Override
    public String writeData(String text){
        WebRepository webRepository=new WebRepositoryImpl();
        return webRepository.writeData(text);
    }

    @Override
    public String readData(){
        WebRepository webRepository=new WebRepositoryImpl();
        return webRepository.readData();
    }

}
