package com.example.project_leap_25cc034_naveenkumar_g.repository;

import org.springframework.stereotype.Repository;

@Repository
public interface WebRepository {
    String writeData(String data);
    String readData();
}
