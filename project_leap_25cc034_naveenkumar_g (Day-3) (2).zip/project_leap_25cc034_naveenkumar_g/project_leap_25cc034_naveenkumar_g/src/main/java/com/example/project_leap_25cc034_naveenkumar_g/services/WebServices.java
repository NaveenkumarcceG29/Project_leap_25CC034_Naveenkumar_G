package com.example.project_leap_25cc034_naveenkumar_g.services;

import com.example.project_leap_25cc034_naveenkumar_g.model.Student;

import java.util.List;

public interface WebServices{
    Student saveStudent(Student student);
    void deleteStudent(Long id);
    List<Student> readStudents();
    Student updateStudent(Student student);
}
