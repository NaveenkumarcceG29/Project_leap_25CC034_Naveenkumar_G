package com.example.project_leap_25cc034_naveenkumar_g.controller;

import com.example.project_leap_25cc034_naveenkumar_g.model.Student;
import com.example.project_leap_25cc034_naveenkumar_g.services.WebServices;
import com.example.project_leap_25cc034_naveenkumar_g.services.impl.WebServicesImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class WebController {
    @Autowired
    private WebServices webService;

    @PostMapping
    public Student addStudent(@RequestBody Student  student){
        return webService.saveStudent(student);
    }
    @GetMapping("/Details")
    List<Student> studentDetails(){
        return webService.readStudents();
    }
    @PostMapping("/update")
    public Student updateStudent (@RequestBody Student student){
        return webService.updateStudent(student);
    }
    @DeleteMapping("/Delete")
    public String deleteStudent(@RequestParam("id") Long id){
        webService.deleteStudent(id);
        return "Deleted Student "+id+"Successfully";
    }
}