package com.example.project_leap_25cc034_naveenkumar_g.repository;

import com.example.project_leap_25cc034_naveenkumar_g.model.Student;
import org.springframework.data.jpa.repository.JpaRepository;


public interface WebRepository extends JpaRepository<Student,Long> {

}
