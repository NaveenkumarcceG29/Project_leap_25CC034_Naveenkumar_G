package com.example.project_leap_25cc034_naveenkumar_g;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectLeap25cc034NaveenkumarGApplication {
	public static void main(String[] args) {
		SpringApplication.run(ProjectLeap25cc034NaveenkumarGApplication.class, args);
	}
}
