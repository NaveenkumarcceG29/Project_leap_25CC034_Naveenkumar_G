package com.example.project_leap_25cc034_naveenkumar_g;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectLeap25cc034NaveenkumarGApplicationTests {

	@Test
	void contextLoads() {
	}

}
