package com.example.Project_leap_25CC034_Naveenkumar_G;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectLeap25Cc034NaveenkumarGApplicationTests {

	@Test
	void contextLoads() {
	}

}
