package com.example.Project_leap_25CC034_Naveenkumar_G.controller;

import com.example.Project_leap_25CC034_Naveenkumar_G.Student;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class WebController {
    @GetMapping("/calculate")
    int calculate(int a, int b, char operation) {
        switch (operation) {
            case '+' -> {
                return a + b;
            }
            case '-' -> {
                return a - b;
            }
            case '*' -> {
                return a * b;
            }
            case '/' -> {
                return a / b;
            }
        }
        return 0;
    }

    @GetMapping("/student")
    public Student getStudentDetails(){
        Student student = new Student();
        student.setName("Naveenkumar");
        student.setDepartment("CCE");
        student.setRollNo("25CC034");
        return student;
    }

}
