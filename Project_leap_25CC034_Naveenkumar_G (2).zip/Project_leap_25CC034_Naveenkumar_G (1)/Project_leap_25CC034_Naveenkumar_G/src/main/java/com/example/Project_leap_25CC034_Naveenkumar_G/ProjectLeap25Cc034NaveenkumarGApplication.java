package com.example.Project_leap_25CC034_Naveenkumar_G;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectLeap25Cc034NaveenkumarGApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectLeap25Cc034NaveenkumarGApplication.class, args);
	}

}
