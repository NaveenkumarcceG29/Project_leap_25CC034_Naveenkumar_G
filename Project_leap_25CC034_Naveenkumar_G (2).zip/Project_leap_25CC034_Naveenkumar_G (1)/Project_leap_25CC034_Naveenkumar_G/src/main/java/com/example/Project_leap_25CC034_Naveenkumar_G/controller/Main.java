package com.example.Project_leap_25CC034_Naveenkumar_G.controller;

public class Main {
    static void main(){
        WebController webcontroller = new WebController();
        IO.print(webcontroller.calculate(10 , 20 , '+')); }
}
